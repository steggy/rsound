cp build/wiringpi.so `php-config --extension-dir`
